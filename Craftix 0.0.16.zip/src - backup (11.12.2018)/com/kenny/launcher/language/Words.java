package com.kenny.launcher.language;

public class Words 
{
	public static String T_FILE;
	public static String T_SETTINGS;
	public static String T_RUN;
	public static String T_NEWS;
	public static String T_CLOSE;
	public static String T_CLOSE_APP;
	public static String T_OPEN;
	public static String T_RESTART;
	public static String T_RCRAFTIX;
	
}
