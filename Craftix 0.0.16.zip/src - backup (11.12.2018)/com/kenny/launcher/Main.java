package com.kenny.launcher;

public class Main 
{	
	public static void main(String [] _launcher_0)
	{
		CraftixLauncher cxLauncher = new CraftixLauncher();
		cxLauncher.run();
	}
}
