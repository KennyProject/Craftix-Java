package com.kenny.craftix.client.resources;

public interface IMetadataSection 
{

}
