package com.kenny.craftix.client.resources;


/**
 * This means that the method is not yet completed and is currently possible to 
 * work.  This is done in order to distinguish working methods that are fully 
 * completed from those methods that are still possible working but not yet completed. 
 * If you know that this method is working please inform the author of the project.
 * I want to say that this annotation is not as does not affect the methods or something 
 * else. Just a note.
 * 
 * @author Kenny
 * 
 * @version 0.0.15
 */
public @interface StillWorking 
{
}
