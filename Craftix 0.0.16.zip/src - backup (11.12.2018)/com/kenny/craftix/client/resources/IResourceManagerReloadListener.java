package com.kenny.craftix.client.resources;

public interface IResourceManagerReloadListener
{
    void onResourceManagerReload(IResourceManager resourceManager);
}