package com.kenny.craftix.client.settings.console;

public class CraftixError extends Error
{
	/**
	 * This Class just extends a original java lang error.
	 */
	private static final long serialVersionUID = 1L;
}
