package com.kenny.craftix.client.gui;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.gui.button.GuiAbstractButton;
import com.kenny.craftix.client.gui.button.IButton;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.settings.InGameSettings;
import com.kenny.craftix.init.TextInit;

public class GuiLatestUpdates extends GuiAdder implements IGui
{

	public List<Gui> guislUpdatesBackground = new ArrayList<Gui>();
	public List<Gui> guislUpdatesButtons = new ArrayList<Gui>();
	
	/**Is the core to load the rest of the game.*/
	public Loader loader;
	
	/**Here all gui-textures.*/
	public Gui gui_lUpdates_updates;
	public Gui gui_lUpdates_border;
	
	/**Here all gui-textures-buttons*/
	public GuiAbstractButton button_lUpdates_back;
	
	public void loadLatestUpdatesScreen()
	{
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	@Override
	public void drawGuis() 
	{
		this.loader = new Loader();
		
		this.gui_lUpdates_border = addGui("guis/menu/gui_border", this.loader, -0.73f, 0.63f, 0.20f, 0.10f);
	}

	@SuppressWarnings("unused")
	@Override
	public void drawGuiButtons() 
	{
		/**
		 * This is custom X and Y values for a for multi-size buttons.
		 */
		float x = 0f, y = 0f;
		if(InGameSettings.guiScaleSmallIn)
		{x = 0.009f; y = 0.012f;}
		
		if(InGameSettings.guiScaleMediumIn)
		{x = 0.01f; y = 0.01f;}
		
		if(InGameSettings.guiScaleLargeIn)
		{x = 0f; y = 0f;}
		
		this.button_lUpdates_back = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f,-0.72f), -0.04f, 0f) 
		{
			public void onClick(IButton button) 
			{
				TextInit.removeLatestUpdatesPage();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initMainPage(textInit.loader);
				GuiRenderManager.renderMainMenu = true;
				GuiRenderManager.renderUpdatesMenu = false;
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_lUpdates_back.show(guislUpdatesButtons);
	}

	@Override
	public void addToList() 
	{
		this.guislUpdatesBackground.add(gui_lUpdates_border);
	}

	@Override
	public void updateButtons() 
	{
		this.button_lUpdates_back.update();
	}
	
}
