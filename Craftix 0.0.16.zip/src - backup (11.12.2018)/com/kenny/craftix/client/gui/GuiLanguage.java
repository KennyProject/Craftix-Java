package com.kenny.craftix.client.gui;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.gui.button.GuiAbstractButton;
import com.kenny.craftix.client.gui.button.IButton;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.scenes.MainMenuScene;
import com.kenny.craftix.client.settings.InGameSettings;
import com.kenny.craftix.init.TextInit;

public class GuiLanguage extends GuiAdder implements IGui
{
	public List<Gui> guisLanguageBackground = new ArrayList<Gui>();
	public List<Gui> guisLanguageButtons = new ArrayList<Gui>();

	/**Is the core to load the rest of the game.*/
	public Loader loader;
	
	/**All init of Language Gui textures.*/
	public Gui gui_language_option;
	public Gui gui_language_optionPanel;
	public Gui gui_language_border;
	public Gui gui_language_background;
	
	/**All init of Language Gui Buttons-textures*/;
	public GuiAbstractButton button_language_back;
	public GuiAbstractButton button_language_en;
	public GuiAbstractButton button_language_ru;
	
	public void loadLanguageScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	@Override
	public void drawGuis() 
	{
		this.gui_language_background = addGui("guis/menu/in_background", this.loader, 0.0f, -0.95f, 1.95f, 1.95f);
		this.gui_language_option = addGui("guis/menu/options", this.loader, 0.0f, 0.75f, 0.40f, 0.45f);
		this.gui_language_optionPanel = addGui("guis/menu/gui_background_small", this.loader, 0.1f, -0.45f, 0.40f, 1.00f);
		this.gui_language_border = addGui("guis/menu/gui_border", this.loader, -0.73f, 0.63f, 0.20f, 0.10f);
	}

	@Override
	public void drawGuiButtons() 
	{
		/**
		 * This is custom X and Y values for a for multi-size buttons.
		 */
		float x = 0f, y = 0f;
		if(InGameSettings.guiScaleSmallIn)
		{x = 0.009f; y = 0.012f;}
		
		if(InGameSettings.guiScaleMediumIn)
		{x = 0.01f; y = 0.01f;}
		
		if(InGameSettings.guiScaleLargeIn)
		{x = 0f; y = 0f;}
		
		this.button_language_back = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f,-0.72f), -0.04f, 0f) 
		{
			public void onClick(IButton button) 
			{
				GuiScaled.isButtonYesNo = true;
				TextInit.removeLanguagePage();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initOptionPage(textInit.loader);
				if(InGameSettings.hasError)
				{
					textInit.initErrorsMessages(textInit.loader);
				}
				GuiRenderManager.renderLanguageMenu = false;
				GuiRenderManager.renderOptionsMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_language_back.show(guisLanguageButtons);
		
		this.button_language_en = new GuiAbstractButton("guis/menu/button_base", 
				new Vector2f(-0.0f, 0.1f), -0.10f + x, -0.03f + y)  
		
		{
			public void onClick(IButton button) 
			{
				MainMenuScene mainScene = new MainMenuScene();
				mainScene.selectEnglishLang();
			}
			public void isVisible(boolean visibleIn) {}
		};
			this.button_language_en.show(guisLanguageButtons);
			
			this.button_language_ru = new GuiAbstractButton("guis/menu/button_base", 
					new Vector2f(-0.0f, -0.1f), -0.10f + x, -0.03f + y)  
			
			{
				public void onClick(IButton button) 
				{
					MainMenuScene mainScene = new MainMenuScene();
					mainScene.selectRussianLang();
				}
				public void isVisible(boolean visibleIn) {}
			};
			this.button_language_ru.show(guisLanguageButtons);
	}

	@Override
	public void addToList() 
	{
		this.guisLanguageBackground.add(gui_language_background);
		this.guisLanguageBackground.add(gui_language_option);
		this.guisLanguageBackground.add(gui_language_optionPanel);
		this.guisLanguageBackground.add(gui_language_border);
	}

	@Override
	public void updateButtons() 
	{
		this.button_language_back.update();
		this.button_language_en.update();
		this.button_language_ru.update();
	}

}
