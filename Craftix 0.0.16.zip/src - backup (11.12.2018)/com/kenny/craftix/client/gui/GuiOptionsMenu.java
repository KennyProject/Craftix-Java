package com.kenny.craftix.client.gui;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.gui.button.GuiAbstractButton;
import com.kenny.craftix.client.gui.button.IButton;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.scenes.WorldScene;
import com.kenny.craftix.client.settings.InGameSettings;
import com.kenny.craftix.init.TextInit;

public class GuiOptionsMenu extends GuiAdder implements IGui
{
	public List<Gui> guisMenuOptionsButtons = new ArrayList<Gui>();
	public List<Gui> guisMenuOptionsBackground = new ArrayList<Gui>();
	private Loader loader;
	public boolean setFullscreen;
	
	/**All init of Options Menu Gui textures.*/
	public Gui gui_options_option;
	public Gui gui_options_background;
	public Gui gui_options_inGameBackground;
	public Gui gui_options_lock;
	public Gui gui_options_tip1;
	public Gui gui_options_border;
	
	/**All init of Options Menu Gui Buttons-textures.*/
	public GuiAbstractButton button_options_back;
	public GuiAbstractButton button_options_back_game;
	public GuiAbstractButton button_options_audio;
	public GuiAbstractButton button_options_graphics;
	public GuiAbstractButton button_options_language;
	public GuiAbstractButton button_fullscreen_yes;
	public GuiAbstractButton button_fullscreen_no;
	public GuiAbstractButton button_fbo_yes;
	public GuiAbstractButton button_fbo_no;
	public GuiAbstractButton button_skybox_yes;
	public GuiAbstractButton button_skybox_no;
	public GuiAbstractButton button_water_yes;
	public GuiAbstractButton button_water_no;
	public GuiAbstractButton button_triangleMode_no;
	public GuiAbstractButton button_triangleMode_yes;
	public GuiAbstractButton button_soundOn;
	public GuiAbstractButton button_soundOff;
	
	public void loadOptionsMenuScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	/**
	 * Load the option screen when user in game scene.
	 */
	public void loadOptionsInGameScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	@Override
	public void drawGuis() 
	{
		this.gui_options_inGameBackground = addGui("guis/menu/in_background", this.loader, 0.0f, -0.95f, 1.95f, 1.95f);
		this.gui_options_option = addGui("guis/menu/options", this.loader, 0.0f, 0.75f, 0.40f, 0.45f);
		this.gui_options_background = addGui("guis/menu/gui_background_with_line", this.loader, -0.21f, -0.45f, 0.80f, 1.0f);
		this.gui_options_lock = addGui("guis/menu/lock", this.loader, -0.07f, -0.2f, 0.10f, 0.20f);
		this.gui_options_tip1 = addGui("guis/menu/button_text", this.loader, -0.73f, 0.65f, 0.20f, 0.10f);
		this.gui_options_border = addGui("guis/menu/gui_border", this.loader, -0.73f, 0.63f, 0.20f, 0.10f);
	}

	@Override
	public void drawGuiButtons() 
	{	
		/**
		 * This is custom X and Y values for a for multi-size buttons.
		 */
		float x = 0f, y = 0f;
		if(InGameSettings.guiScaleSmallIn)
		{
			x = 0.045f; y = 0.005f;
		}
		if(InGameSettings.guiScaleMediumIn)
		{
			x = 0.02f; y = 0.015f;
		}
		if(InGameSettings.guiScaleLargeIn)
		{
			x = 0f; y = 0f;
		}
		
		
		this.button_options_back = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f,-0.72f), -0.04f, 0f) 
		{
			@Override
			public void onClick(IButton button) 
			{
				TextInit textInit = new TextInit();
				TextInit.removeOptionsPage();
				//TextInit.removeLoadingWorldPage();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initMainPage(textInit.loader);
				GuiRenderManager.renderOptionsMenu = false;
				Craftix.saveAllGameOptions();
				GuiRenderManager.renderMainMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		if(Craftix.isInMenuScene && !Craftix.isInWorldScene)
		{
			this.button_options_back.show(guisMenuOptionsButtons);
		}
		
		this.button_options_back_game = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f,-0.72f), -0.04f, 0f) 
		{
			@Override
			public void onClick(IButton button) 
			{
				TextInit.removeOptionsInGamePage();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initPausePage(textInit.loader);
				GuiRenderManager.renderOptionsInGame = false;
				Craftix.saveAllGameOptions();
				WorldScene.inGameOptions = false;
				GuiRenderManager.renderInGameMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		if(Craftix.isInWorldScene && !Craftix.isInMenuScene)
		{
			this.button_options_back_game.show(guisMenuOptionsButtons);
		}
		
		this.button_options_graphics = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f, 0.22f), -0.04f, 0f)   
		{
			@Override
			public void onClick(IButton button) 
			{
				TextInit textInit = new TextInit();
				TextInit.removeOptionsPage();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initGrapthicsPage(textInit.loader);
				GuiRenderManager.renderOptionsMenu = false;
				GuiRenderManager.renderGraphicMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		if(!Craftix.isInWorldScene && Craftix.isInMenuScene)
		{
			this.button_options_graphics.show(guisMenuOptionsButtons);
		}
		
		this.button_options_language = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f, 0.00f), -0.04f, 0.0f)  
		{
			@Override
			public void onClick(IButton button) 
			{
				TextInit.removeOptionsPage();
				TextInit.removeErrorsMessages();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initLanguagePage(textInit.loader);
				GuiRenderManager.renderOptionsMenu = false;
				GuiRenderManager.renderLanguageMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		if(!Craftix.isInWorldScene && Craftix.isInMenuScene)
		{
			this.button_options_language.show(guisMenuOptionsButtons);
		}
		
		this.button_options_audio = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f, 0.44f), -0.04f, 0f)  
		{
			@Override
			public void onClick(IButton button) 
			{
				TextInit.removeOptionsPage();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initAudioPage(textInit.loader);
				GuiRenderManager.renderOptionsMenu = false;
				GuiRenderManager.renderAudioMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		if(Craftix.isInMenuScene && !Craftix.isInWorldScene)
		{
			this.button_options_audio.show(guisMenuOptionsButtons);
		}
		
		this.button_fullscreen_yes = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.55f, 0.4f), -0.215f + x, -0.005f + y) 
		{
			@Override
			public void onClick(IButton button) 
			{
				Logger LOGGER = LogManager.getLogger();
				Craftix craftix = new Craftix();
		        try 
		        {
		        	button.hide(guisMenuOptionsButtons);
					craftix.initDisplayMode(1280, 768, !Display.isFullscreen());
					InGameSettings.useFullscreenIn = false;
					GuiYesNo.isYesOptionFS = InGameSettings.useFullscreenIn;
					button_fullscreen_no.show(guisMenuOptionsButtons);
				} 
		        catch (LWJGLException e) 
		        {
					LOGGER.info("Can't change display mode.");
					e.printStackTrace();
				}
		      
			}
			public void isVisible(boolean visibleIn) {}
		};
		
		this.button_fullscreen_no = new GuiAbstractButton("guis/menu/button_no",
				new Vector2f(-0.55f, 0.4f), -0.215f + x, -0.005f + y) 
		{
			
			@Override
			public void onClick(IButton button) 
			{
				Logger LOGGER = LogManager.getLogger();
				Craftix craftix = new Craftix();
		        try 
		        {
		        	button.hide(guisMenuOptionsButtons);
					craftix.initDisplayMode(craftix.getDisplayWidth(), 
							craftix.getDisplayHeight(), !Display.isFullscreen());
					InGameSettings.useFullscreenIn = true;
					GuiYesNo.isYesOptionFS = InGameSettings.useFullscreenIn;
					button_fullscreen_yes.show(guisMenuOptionsButtons);
				} 
		        catch (LWJGLException e) 
		        {
					LOGGER.info("Can't change display mode.");
					e.printStackTrace();
				}
			}
			public void isVisible(boolean visibleIn) {}
		
		};
		if(GuiYesNo.isYesOptionFS)
		{
			this.button_fullscreen_yes.show(guisMenuOptionsButtons);
		}else{
			this.button_fullscreen_no.show(guisMenuOptionsButtons);
		}
		
		this.button_fbo_yes = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.55f, 0.2f), -0.215f + x, -0.005f + y) 
		{
			
			@Override
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.disableFbo();
				GuiYesNo.isYesOptionFBO = InGameSettings.useFboIn;
				button_fbo_no.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		
		this.button_fbo_no = new GuiAbstractButton("guis/menu/button_no", 
				new Vector2f(-0.55f, 0.2f), -0.215f + x, -0.005f + y) 
		{
			
			@Override
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.enableFbo();
				GuiYesNo.isYesOptionFBO = InGameSettings.useFboIn;
				button_fbo_yes.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		if(GuiYesNo.isYesOptionFBO)
		{
			this.button_fbo_yes.show(guisMenuOptionsButtons);
		}else{
			this.button_fbo_no.show(guisMenuOptionsButtons);
		}
		
		this.button_skybox_yes = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.55f, 0.0f), -0.215f + x, -0.005f + y) 
		{
			
			@Override
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.disableRenderSkyBox();
				GuiYesNo.isYesOptionRS = InGameSettings.renderSkyBoxIn;
				button_skybox_no.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		
		this.button_skybox_no = new GuiAbstractButton("guis/menu/button_no", 
				new Vector2f(-0.55f, 0.0f), -0.215f + x, -0.005f + y) 
		{
			
			@Override
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.enableRenderSkyBox();
				GuiYesNo.isYesOptionRS = InGameSettings.renderSkyBoxIn;
				button_skybox_yes.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		if(GuiYesNo.isYesOptionRS)
		{
			this.button_skybox_yes.show(guisMenuOptionsButtons);
		}else{
			this.button_skybox_no.show(guisMenuOptionsButtons);
		}
		
		this.button_water_yes = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.55f, -0.2f), -0.215f + x, -0.005f + y) 
		{
			@Override
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.disableRenderWater();
				GuiYesNo.isYesOptionRW = InGameSettings.renderWaterIn;
				button_water_no.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		
		this.button_water_no = new GuiAbstractButton("guis/menu/button_no", 
				new Vector2f(-0.55f, -0.2f), -0.215f + x, -0.005f + y) 
		{
			@Override
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.enableRenderWater();
				GuiYesNo.isYesOptionRW = InGameSettings.renderWaterIn;
				button_water_yes.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		if(GuiYesNo.isYesOptionRW)
		{
			this.button_water_yes.show(guisMenuOptionsButtons);
		}else{
			this.button_water_no.show(guisMenuOptionsButtons);
		}
		
		this.button_triangleMode_yes = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.15f, -0.4f), -0.215f + x, -0.005f + y) 
		{
			@Override
			public void onClick(IButton button) 
			{
				@SuppressWarnings("unused")
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				
				button_triangleMode_no.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
		};
		
		this.button_triangleMode_no = new GuiAbstractButton("guis/menu/button_no", 
				new Vector2f(-0.55f, -0.4f), -0.215f + x, -0.005f + y) 
		{
			@Override
			public void onClick(IButton button) 
			{
				@SuppressWarnings("unused")
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				
				button_triangleMode_yes.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
	
		this.button_triangleMode_no.show(guisMenuOptionsButtons);
		
		this.button_soundOn = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.00f, 0.21f), -0.215f + x, -0.005f + y) 
		{
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.disableAudio();
				GuiYesNo.isYesOptionAudio = InGameSettings.useAudioIn;
				button_soundOff.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		
		this.button_soundOff = new GuiAbstractButton("guis/menu/button_no", 
				new Vector2f(-0.00f, 0.21f), -0.215f + x, -0.005f + y) 
		{
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisMenuOptionsButtons);
				inGameSettings.enableAudio();
				GuiYesNo.isYesOptionAudio = InGameSettings.useAudioIn;
				button_soundOn.show(guisMenuOptionsButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		if(Craftix.isInWorldScene && !Craftix.isInMenuScene)
		{
			if(GuiYesNo.isYesOptionAudio)
			{
				this.button_soundOn.show(guisMenuOptionsButtons);
			}else{
				this.button_soundOff.show(guisMenuOptionsButtons);
			}
		}

	}
	


	@Override
	public void addToList() 
	{
		this.guisMenuOptionsButtons.add(gui_options_inGameBackground);
		this.guisMenuOptionsButtons.add(gui_options_option);
		this.guisMenuOptionsButtons.add(gui_options_background);
		this.guisMenuOptionsButtons.add(gui_options_lock);
		this.guisMenuOptionsButtons.add(gui_options_border);
	}

	@Override
	public void updateButtons() 
	{
		if(Craftix.isInMenuScene && !Craftix.isInWorldScene)
		{
			this.button_options_back.update();
			this.button_options_audio.update();
			this.button_options_graphics.update();
			this.button_options_language.update();
		}
		
		if(Craftix.isInWorldScene && !Craftix.isInMenuScene)
		{
			this.button_options_back_game.update();
			if(GuiYesNo.isYesOptionAudio == true)
			{this.button_soundOn.updateMulti(); this.button_soundOff.updateMulti();} 
			if(GuiYesNo.isYesOptionAudio == false)
			{this.button_soundOff.updateMulti(); this.button_soundOn.updateMulti();}
		}
		
		if(GuiYesNo.isYesOptionFS == true)
		{this.button_fullscreen_yes.updateMulti(); this.button_fullscreen_no.updateMulti();} 
		if(GuiYesNo.isYesOptionFS == false)
		{this.button_fullscreen_no.updateMulti(); this.button_fullscreen_yes.updateMulti();}
		
		if(GuiYesNo.isYesOptionFBO == true)
		{this.button_fbo_yes.updateMulti(); this.button_fbo_no.updateMulti();} 
		if(GuiYesNo.isYesOptionFBO == false)
		{this.button_fbo_no.updateMulti(); this.button_fbo_yes.updateMulti();}
		
		if(GuiYesNo.isYesOptionRS == true)
		{this.button_skybox_yes.updateMulti(); this.button_skybox_no.updateMulti();} 
		if(GuiYesNo.isYesOptionRS == false)
		{this.button_skybox_no.updateMulti(); this.button_skybox_yes.updateMulti();}
		
		if(GuiYesNo.isYesOptionRW == true)
		{this.button_water_yes.updateMulti(); this.button_water_no.updateMulti();} 
		if(GuiYesNo.isYesOptionRW == false)
		{this.button_water_no.updateMulti(); this.button_water_yes.updateMulti();}
		
		this.button_triangleMode_no.updateMulti();
		this.button_triangleMode_yes.updateMulti();
	}
}
