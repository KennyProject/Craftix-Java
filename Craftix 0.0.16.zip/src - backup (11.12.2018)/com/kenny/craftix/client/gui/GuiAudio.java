package com.kenny.craftix.client.gui;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.gui.button.GuiAbstractButton;
import com.kenny.craftix.client.gui.button.IButton;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.settings.InGameSettings;
import com.kenny.craftix.init.TextInit;

public class GuiAudio extends GuiAdder implements IGui 
{

	public List<Gui> guisAudioBackground = new ArrayList<Gui>();
	public List<Gui> guisAudioButtons = new ArrayList<Gui>();
	
	/**Is the core to load the rest of the game.*/
	public Loader loader;
	
	/**All init of Audio Gui textures.*/
	public Gui gui_audio_audio;
	public Gui gui_audio_background_rot;
	public Gui gui_audio_border;
	public Gui gui_audio_background;
	
	/**All init of Audio Gui Buttons-textures*/;
	public GuiAbstractButton button_audio_back;
	public GuiAbstractButton button_audio_back_game;
	public GuiAbstractButton button_soundOn;
	public GuiAbstractButton button_soundOff;
	
	public void loadAudioScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	public void loadAudioInGameScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	@Override
	public void drawGuis() 
	{
		this.gui_audio_background = addGui("guis/menu/in_background", this.loader, 0.0f, -0.95f, 1.95f, 1.95f);
		this.gui_audio_audio = addGui("guis/menu/options", this.loader, 0.0f, 0.75f, 0.40f, 0.45f);
		this.gui_audio_background_rot = addGui("guis/menu/gui_background_small_rot", this.loader, -0.21f, -0.35f, 0.70f, 0.60f);
		this.gui_audio_border = addGui("guis/menu/gui_border", this.loader, -0.73f, 0.63f, 0.20f, 0.10f);
	}

	@Override
	public void drawGuiButtons() 
	{
		/**
		 * This is custom X and Y values for a for multi-size buttons.
		 */
		float x = 0f, y = 0f;
		if(InGameSettings.guiScaleSmallIn)
		{
			x = 0.045f; y = 0.005f;
		}
		if(InGameSettings.guiScaleMediumIn)
		{
			x = 0.02f; y = 0.015f;
		}
		if(InGameSettings.guiScaleLargeIn)
		{
			x = 0f; y = 0f;
		}
		
		
		this.button_audio_back = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f,-0.72f), -0.04f, 0f) 
			{
				public void onClick(IButton button) 
				{
					TextInit textInit = new TextInit();
					TextInit.removeAudioPage();
					textInit.loadDefaultFonts(textInit.loader);
					textInit.initOptionPage(textInit.loader);
					GuiRenderManager.renderAudioMenu = false;
					GuiRenderManager.renderOptionsMenu = true;
				}
				public void isVisible(boolean visibleIn) {}
		};
		if(!Craftix.isInWorldScene && Craftix.isInMenuScene)
		{
			this.button_audio_back.show(guisAudioButtons);
		}
		
		this.button_audio_back_game = new GuiAbstractButton("guis/menu/button_medium_base", 
				new Vector2f(0.72f,-0.72f), -0.04f, 0f) 
			{
				public void onClick(IButton button) 
				{
					TextInit textInit = new TextInit();
					TextInit.removeAudioInGame();
					textInit.loadDefaultFonts(textInit.loader);
					textInit.initOptionInGamePage(textInit.loader);
					GuiRenderManager.renderAudioMenu = false;
					GuiRenderManager.renderOptionsInGame = true;
				}
				public void isVisible(boolean visibleIn) {}
		};
		if(Craftix.isInWorldScene && !Craftix.isInMenuScene)
		{
			this.button_audio_back_game.show(guisAudioButtons);
		}
		
		this.button_soundOn = new GuiAbstractButton("guis/menu/button_yes", 
				new Vector2f(-0.49f, 0.05f), -0.215f + x, -0.005f + y) 
		{
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisAudioButtons);
				inGameSettings.disableAudio();
				GuiYesNo.isYesOptionAudio = InGameSettings.useAudioIn;
				button_soundOff.show(guisAudioButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		
		this.button_soundOff = new GuiAbstractButton("guis/menu/button_no", 
				new Vector2f(-0.49f, 0.05f), -0.215f + x, -0.005f + y) 
		{
			public void onClick(IButton button) 
			{
				InGameSettings inGameSettings = new InGameSettings();
				button.hide(guisAudioButtons);
				inGameSettings.enableAudio();
				GuiYesNo.isYesOptionAudio = InGameSettings.useAudioIn;
				button_soundOn.show(guisAudioButtons);
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		if(GuiYesNo.isYesOptionAudio)
		{
			this.button_soundOn.show(guisAudioButtons);
		}else{
			this.button_soundOff.show(guisAudioButtons);
		}

	}

	@Override
	public void addToList() 
	{
		this.guisAudioBackground.add(gui_audio_background);
		this.guisAudioBackground.add(gui_audio_audio);
		this.guisAudioBackground.add(gui_audio_background_rot);
		this.guisAudioBackground.add(gui_audio_border);
	}

	@Override
	public void updateButtons() 
	{
		if(Craftix.isInMenuScene && !Craftix.isInWorldScene)
		{this.button_audio_back.update();}
		
		if(Craftix.isInWorldScene && !Craftix.isInMenuScene)
		{this.button_audio_back_game.update();}
		
		if(GuiYesNo.isYesOptionAudio == true)
		{this.button_soundOn.updateMulti(); this.button_soundOff.updateMulti();} 
		if(GuiYesNo.isYesOptionAudio == false)
		{this.button_soundOff.updateMulti(); this.button_soundOn.updateMulti();}
	}
	
}
