package com.kenny.craftix.client.gui;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.renderer.GlHelper;
import com.kenny.craftix.client.resources.StillWorking;

public class Gui 
{
	private int texture;
	/**This is position of gui texture*/
	private Vector2f position;
	/**This is scale size of gui texture*/
	private Vector2f scale;
	/**Rotation Gui on X axis*/
	public float rotX;
	/**Rotation Gui on Y axis*/
	public float rotY;
	private Vector4f colour;
	public Craftix craftix;
	
	public Gui(int texture, Vector2f position, Vector2f scale, float rotX, float rotY) 
	{
		this.texture = texture;
		this.position = position;
		this.scale = scale;
		this.rotX = rotX;
		this.rotY = rotY;
	}
	
	public Gui(int texture, Vector2f position, Vector2f scale) 
	{
		this.texture = texture;
		this.position = position;
		this.scale = scale;
	}
	
	public void increaseRotation(float dX, float dY)
	{
		this.rotX += dX;
		this.rotY += dY;
	}
	
	public int getTexture() 
	{
		return texture;
	}

	public Vector2f getPosition() 
	{
		return position;
	}
	
	public void setTexture(int texture) 
	{
		this.texture = texture;
	}

	public void setPosition(Vector2f position) 
	{
		this.position = position;
	}

	public void setCraftix(Craftix craftix) 
	{
		this.craftix = craftix;
	}
	
	public Vector2f getScale() 
	{
		return scale;
	}

	public void setScale(Vector2f scale)
	{
		this.scale = scale;
	}
	
	public Vector4f getColor() 
	{
		return this.colour;
	}


	public void setColor(Vector4f color) 
	{
		this.colour = color;
	}
	
	/************************GUI NEW TEST SYSTEM*******************************************/
	/**@author Kenny*/
	
	/**
	 * Draws a thin horizontal line between two points on the screen.
	 */
	protected void drawHorizontalLine(int startX, int endX, int y, int color)
	{
		if (endX < startX)
		{
			int i = startX;
			startX = endX;
			endX = i;
		}
		drawRect(startX, y, endX + 1, y + 1, color);
	}
	
	 /**
     * Draw a 1 pixel wide vertical line. Args : x, y1, y2, color
     */
    protected void drawVerticalLine(int x, int startY, int endY, int color)
    {
        if (endY < startY)
        {
            int i = startY;
            startY = endY;
            endY = i;
        }

        drawRect(x, startY + 1, x + 1, endY, color);
    }
	
	/**
     * Draws a solid color rectangle with the specified coordinates and color.
     */
	@StillWorking
	public static void drawRect(int left, int top, int right, int bottom, int color)
	{
		if(left < right)
		{
			int i = left;
			left = right;
			right = i;
		}
		
		if(top < bottom)
		{
			int j = top;
			top = bottom;
			bottom = j;
		}
		
		float f3  = (float)(color >> 24 & 255) / 255.0f;
		float f  = (float)(color >> 16 & 255) / 255.0f;
		float f1  = (float)(color >> 8 & 255) / 255.0f;
		float f2  = (float)(color & 255) / 255.0f;
		GlHelper.glEnable(GL11.GL_BLEND);
		GlHelper.glDisable(GL11.GL_TEXTURE_2D);
		GlHelper.glBlendFunction(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GlHelper.glColor4f(f, f1, f2, f3);
		/**Draw stage*/
		GlHelper.glEnable(GL11.GL_TEXTURE_2D);
		GlHelper.glDisable(GL11.GL_BLEND);
		
	}
	
}
