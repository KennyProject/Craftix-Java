package com.kenny.craftix.client.gui;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.gui.button.GuiAbstractButton;
import com.kenny.craftix.client.gui.button.IButton;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.settings.InGameSettings;
import com.kenny.craftix.client.shaders.FrameBuffer;
import com.kenny.craftix.init.TextInit;

public class GuiMainMenu extends GuiAdder implements IGui
{

	public List<Gui> guisMenuMainBackground = new ArrayList<Gui>();
	public List<Gui> guisMenuMainButtons = new ArrayList<Gui>();
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();
	protected static final float DISTANCE_BEETWEN_BUTTON = 0.22f;
	/**Is the core to load the rest of the game.*/
	public Loader loader;
	protected FrameBuffer waterFrameBuffer;
	@SuppressWarnings("unused")
	private Craftix craftix;
	public static boolean update = true;
	
	/**All init of Main Menu Gui textures.*/
	public Gui gui_mainMenu_logo;
	public Gui gui_mainMenu_logo_2;
	public Gui gui_mainMenu_in_background;
	public Gui gui_mainMenu_in_1;
	public Gui gui_mainMenu_in_2;
	public Gui gui_mainMenu_closeGameBackground;
	
	/**All init of Main Menu Gui Buttons-textures*/;
	public GuiAbstractButton button_mainmenu_updates;
	public GuiAbstractButton button_mainMenu_close;
	public GuiAbstractButton button_mainMenu_website;
	public GuiAbstractButton button_mainMenu_singleplayer;
	public GuiAbstractButton button_mainMenu_multiplayer;
	public GuiAbstractButton button_mainMenu_options;
	public GuiAbstractButton button_mainMenu_credits;
	public GuiAbstractButton button_mainMenu_quitGame;
	public GuiAbstractButton button_mainMenu_return;
	public GuiAbstractButton button_mainMenu_quit;

	/**
	 * Load actually created Main Menu Screen.
	 */
	public void loadMainMenuScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		
		this.addToList();
		this.drawGuiButtons();
		//this.addToListCloseGameBackground();
	}
	
	@Override
	public void drawGuis()
	{
		this.gui_mainMenu_in_background = addGui("guis/menu/panorama_overlay", this.loader, 0.0f, 0.11f, 1.95f, 1.2f);
		this.gui_mainMenu_closeGameBackground = addGui("guis/menu/gui_border", this.loader, 0f, 0f, 0.60f, 0.50f);
		this.gui_mainMenu_logo = addGui("guis/menu/logo", this.loader, 0.0f, 0.72f, 0.50f, 0.70f);
		this.gui_mainMenu_logo_2 = addGui("guis/menu/logo_2", this.loader, 0.0f, 0.40f, 0.15f, 0.25f, 1f, 0f);
		this.gui_mainMenu_in_1 = addGui("guis/menu/in_1", this.loader, 0.0f, -0.20f, 0.50f, 0.30f);
		this.gui_mainMenu_in_2 = addGui("guis/menu/in_2", this.loader, 0.0f, -0.80f, 0.50f, 0.30f);
	}
	
	@Override
	public void drawGuiButtons()
	{
		/**
		 * This is custom X and Y values for a for multi-size buttons.
		 */
		float x = 0f, y = 0f;
		float posX = 0f, posY = 0f;
		if(InGameSettings.guiScaleSmallIn)
		{
			x = -0.004f; y = 0.06f;
			posX = -0.1f; posY = 0f;
		}
		if(InGameSettings.guiScaleMediumIn)
		{
			x = 0.004f; y = 0.04f;
			posX = -0.05f; posY = 0f;
		}
		if(InGameSettings.guiScaleLargeIn)
		{
			x = 0.006f; y = 0.006f;
			posX = 0f; posY = 0f;
		}
		
		
		this.button_mainmenu_updates = new GuiAbstractButton("guis/menu/button_question",
				new Vector2f(-0.85f, 0.8f), -0.18f - x, 0.06f - y) 
		{

			public void onClick(IButton button) 
			{
				TextInit.removeMainPage();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initLatestUpdatePage(textInit.loader);
				GuiRenderManager.renderMainMenu = false;
				GuiRenderManager.renderUpdatesMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		
		};
		this.button_mainmenu_updates.show(guisMenuMainButtons);
		
		this.button_mainMenu_close = new GuiAbstractButton("guis/menu/button_exit",
					new Vector2f(0.9f, 0.8f), -0.18f - x, 0.06f - y) 
		{
	
			public void onClick(IButton button) 
			{
				TextInit.removeMainPage();
				button_mainMenu_singleplayer.hide(guisMenuMainButtons);
				button_mainMenu_multiplayer.hide(guisMenuMainButtons);
				button_mainMenu_options.hide(guisMenuMainButtons);
				button_mainMenu_credits.hide(guisMenuMainButtons);
				button_mainMenu_quitGame.hide(guisMenuMainButtons);
				update = false;
				button.isVisible(true);
				button_mainMenu_return.show(guisMenuMainButtons);
				button_mainMenu_quit.show(guisMenuMainButtons);
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initQuitTheGamePage(textInit.loader);
				
			}
			public void isVisible(boolean visibleIn) {}
			
		};
		this.button_mainMenu_close.show(guisMenuMainButtons);
		if(Keyboard.isKeyDown(Keyboard.KEY_2))
		{
			this.button_mainMenu_close.hide(guisMenuMainButtons);
		}
		
		this.button_mainMenu_website = new GuiAbstractButton("guis/menu/button_website",
				new Vector2f(0.74f - posX, 0.8f - posY), -0.18f - x, 0.06f - y) 
		{
	
			public void onClick(IButton button) 
			{
				Craftix.LOGGER.info("https://www.youtube.com/watch?v=iYACQafSi8g");
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_mainMenu_website.show(guisMenuMainButtons);
		
		this.button_mainMenu_singleplayer = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0f, 0f)) 
			{
			public void onClick(IButton button)
			{
				
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(loader);
				textInit.initSingleplayerPage(loader);
				TextInit.removeMainPage();
				GuiRenderManager.renderMainMenu = false;
				GuiRenderManager.renderSingleplayerMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
			};
		this.button_mainMenu_singleplayer.show(guisMenuMainButtons);
			
		this.button_mainMenu_multiplayer = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0f, -0.22f)) 
			{
				public void onClick(IButton button){}//Craftix.isInWorldScene = true; Craftix.isInMenuScene = false;}
				public void isVisible(boolean visibleIn) {}
			};
			this.button_mainMenu_multiplayer.show(guisMenuMainButtons);	
		
		this.button_mainMenu_options = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0f, -0.44f)) 
		{
			
			public void onClick(IButton button) 
			{
				GuiScaled.isButtonYesNo = true;
				TextInit textInit = new TextInit();
				TextInit.removeMainPage();
				textInit.loadDefaultFonts(textInit.loader);
				//textInit.initLoadingWorldPage();
				textInit.initOptionPage(textInit.loader);
				GuiRenderManager.renderMainMenu = false;
				GuiRenderManager.renderOptionsMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_mainMenu_options.show(guisMenuMainButtons);
		
		this.button_mainMenu_credits = new GuiAbstractButton("guis/menu/button_base", 
				new Vector2f(0f, -0.66f)) 
		{
			public void onClick(IButton button) 
			{
				TextInit textInit = new TextInit();
				TextInit.removeMainPage();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initCreditsPage(textInit.loader);
				GuiRenderManager.renderMainMenu = false;
				GuiRenderManager.renderCreditsMenu = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_mainMenu_credits.show(guisMenuMainButtons);

		this.button_mainMenu_quitGame = new GuiAbstractButton("guis/menu/button_base", 
				new Vector2f(0f, -0.88f)) 
		{
			public void onClick(IButton button) 
			{
				TextInit.removeMainPage();
				button_mainMenu_singleplayer.hide(guisMenuMainButtons);
				button_mainMenu_multiplayer.hide(guisMenuMainButtons);
				button_mainMenu_options.hide(guisMenuMainButtons);
				button_mainMenu_credits.hide(guisMenuMainButtons);
				button_mainMenu_quitGame.hide(guisMenuMainButtons);
				update = false;
				button.isVisible(true);
				button_mainMenu_return.show(guisMenuMainButtons);
				button_mainMenu_quit.show(guisMenuMainButtons);
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initQuitTheGamePage(textInit.loader);
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_mainMenu_quitGame.show(guisMenuMainButtons);
		
		this.button_mainMenu_return = new GuiAbstractButton("guis/menu/button_base", 
				new Vector2f(-0.20f, -0.35f), -0.10f, 0f) 
		{
			public void onClick(IButton button) 
			{
				TextInit.removeQuitTheGamePage();
				TextInit textInit = new TextInit();
				button_mainMenu_singleplayer.show(guisMenuMainButtons);
				button_mainMenu_multiplayer.show(guisMenuMainButtons);
				button_mainMenu_options.show(guisMenuMainButtons);
				button_mainMenu_credits.show(guisMenuMainButtons);
				button_mainMenu_quitGame.show(guisMenuMainButtons);
				button.hide(guisMenuMainButtons);
				button_mainMenu_quit.hide(guisMenuMainButtons);
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initMainPage(textInit.loader);
				update = true;
			}
			public void isVisible(boolean visibleIn) {}
		};
		
		this.button_mainMenu_quit = new GuiAbstractButton("guis/menu/button_base", 
				new Vector2f(0.20f, -0.35f), -0.10f, 0f) 
		{
			public void onClick(IButton button) 
			{
				Craftix cx = new Craftix();
				cx.shutdown();
			}
			public void isVisible(boolean visibleIn) {}
		};
		
	}

	
	@Override
	public void addToList()
	{
		this.guisMenuMainBackground.add(gui_mainMenu_in_background);
		this.guisMenuMainButtons.add(gui_mainMenu_logo);
		this.guisMenuMainButtons.add(gui_mainMenu_logo_2);
	}
	
	public void addToListCloseGameBackground()
	{
		
	}

	@Override
	public void updateButtons() 
	{
		if(update)
		{
			this.button_mainmenu_updates.update();
			this.button_mainMenu_close.update();
			this.button_mainMenu_website.update();
			this.button_mainMenu_singleplayer.update();
			this.button_mainMenu_multiplayer.update();
			this.button_mainMenu_options.update();
			this.button_mainMenu_credits.update();
			this.button_mainMenu_quitGame.update();
		} else {
			this.button_mainMenu_return.update();
			this.button_mainMenu_quit.update();
		}
	}
		
	
	public void removeButtons()
	{
		this.button_mainMenu_close.hide(guisMenuMainButtons);
		this.button_mainMenu_website.hide(guisMenuMainButtons);
		this.button_mainMenu_singleplayer.hide(guisMenuMainButtons);
		this.button_mainMenu_multiplayer.hide(guisMenuMainButtons);
		this.button_mainMenu_options.hide(guisMenuMainButtons);
		this.button_mainMenu_credits.hide(guisMenuMainButtons);
		this.button_mainMenu_quitGame.hide(guisMenuMainButtons);
		this.button_mainMenu_return.hide(guisMenuMainButtons);
	}
	
	public void addWhenRemovedButtons()
	{
		this.button_mainMenu_close.show(guisMenuMainButtons);
		this.button_mainMenu_website.show(guisMenuMainButtons);;
		this.button_mainMenu_singleplayer.show(guisMenuMainButtons);
		this.button_mainMenu_multiplayer.show(guisMenuMainButtons);
		this.button_mainMenu_options.show(guisMenuMainButtons);
		this.button_mainMenu_credits.show(guisMenuMainButtons);
		this.button_mainMenu_quitGame.show(guisMenuMainButtons);
	}

}
