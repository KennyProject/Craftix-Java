package com.kenny.craftix.client.gui;

import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.shaders.FrameBuffer;

public class GuiAdder
{
	/**
	 * Simple add a gui texture on screen of the game.
	 */
	public Gui addGui(String guiFile, Loader loader, float x, float y, float scaleX, float scaleY)
	{
		return new Gui(loader.loadTexture(guiFile), 
				new Vector2f(x, y), new Vector2f(scaleX, scaleY));
	}
	
	public Gui addGui(String guiFile, Loader loader, float x, float y, float scaleX, float scaleY
			, float rotX, float rotY)
	{
		return new Gui(loader.loadTexture(guiFile), 
				new Vector2f(x, y), new Vector2f(scaleX, scaleY), rotX, rotY);
	}
	
	public void addGuiButton()
	{
		//return new AbstactButton("button", new Vector2f(0, 0), new Vector2f(0.3f, 0.1f));
	}
	
	/***
	 * Add the screen with type a gui with reflection texture effect.
	 */
	public Gui addGuiReflection(FrameBuffer frameBuffer, float x, float y, float scaleX, float scaleY)
	{
		return new Gui(frameBuffer.getReflectionTexture(), 
				new Vector2f(x, y), new Vector2f(scaleX, scaleY));
	}
}
