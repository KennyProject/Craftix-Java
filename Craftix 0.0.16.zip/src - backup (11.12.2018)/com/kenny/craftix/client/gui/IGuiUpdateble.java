package com.kenny.craftix.client.gui;

public interface IGuiUpdateble 
{
	public void onUpdate();
}
