package com.kenny.craftix.client.gui;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.gui.button.GuiAbstractButton;
import com.kenny.craftix.client.gui.button.IButton;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.scenes.WorldScene;
import com.kenny.craftix.init.TextInit;

public class GuiInGameMenu extends GuiAdder implements IGui
{
	public List<Gui> guisInGameMenuBackground = new ArrayList<Gui>();
	public List<Gui> guisInGameMenuButtons = new ArrayList<Gui>();
	private Loader loader;
	
	/**All init of In-Game Menu Gui textures.*/
	public Gui gui_ingame_background;
	public Gui gui_ingame_pause;

	/**All init of In-Game Menu Gui Buttons-textures*/;
	public GuiAbstractButton button_ingame_resume;
	public GuiAbstractButton button_ingame_saveWorld;
	public GuiAbstractButton button_ingame_options;
	public GuiAbstractButton button_ingame_backToMenu;
	public GuiAbstractButton button_ingame_closeGame;
	
	public void loadInGameMenuScreen()
	{
		this.loader = new Loader();
		this.drawGuis();
		this.addToList();
		this.drawGuiButtons();
	}
	
	@Override
	public void drawGuis() 
	{
		this.gui_ingame_background = addGui("guis/game/background", this.loader, 0.25f, -0.25f, 1.40f, 1.40f);
		this.gui_ingame_pause = addGui("guis/game/pause", this.loader,  0.0f, 0.75f, 0.40f, 0.45f);
	}

	@Override
	public void drawGuiButtons() 
	{
		this.button_ingame_resume = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0.006f, 0.22f), 0f, 0f) 
			{

			public void onClick(IButton button) 
			{
				TextInit.removeInGamePausePage();
				GuiRenderManager.renderGame = true;
				GuiRenderManager.renderInGameMenu = false;
				Craftix.isGamePause = false;
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_ingame_resume.show(guisInGameMenuButtons);
		
		this.button_ingame_saveWorld = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(-0.186f, 0.0f), -0.08f, 0f) 
			{
			public void onClick(IButton button) {}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_ingame_saveWorld.show(guisInGameMenuButtons);
		
		this.button_ingame_options = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0.212f, 0.0f), -0.08f, 0f) 
			{
				public void onClick(IButton button) 
				{
					TextInit.removeInGamePausePage();
					TextInit textInit = new TextInit();
					textInit.loadDefaultFonts(textInit.loader);
					textInit.initOptionInGamePage(textInit.loader);
					Craftix.isGamePause = true;
					WorldScene.inGameOptions = true;
					GuiRenderManager.renderInGameMenu = false;
					GuiRenderManager.renderOptionsInGame = true;
				}
				public void isVisible(boolean visibleIn) {}
		};
		this.button_ingame_options.show(guisInGameMenuButtons);
		
		this.button_ingame_backToMenu = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0.006f, -0.22f), 0f, 0f)  
			{
			public void onClick(IButton button) 
			{
				TextInit.removeInGamePausePage();
				TextInit textInit = new TextInit();
				textInit.loadDefaultFonts(textInit.loader);
				textInit.initSingleplayerPage(textInit.loader);
				Craftix.backToMenu = true;
				Craftix.quitGameScene = true;
				Craftix.isGamePause = false;
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_ingame_backToMenu.show(guisInGameMenuButtons);
		
		this.button_ingame_closeGame = new GuiAbstractButton("guis/menu/button_base",
				new Vector2f(0.006f, -0.44f), 0f, 0f) 
		{
			public void onClick(IButton button) 
			{
				Craftix craftix = new Craftix();
				craftix.shutdown();
			}
			public void isVisible(boolean visibleIn) {}
		};
		this.button_ingame_closeGame.show(guisInGameMenuButtons);
	}

	@Override
	public void addToList()
	{
		this.guisInGameMenuBackground.add(gui_ingame_background);
		this.guisInGameMenuBackground.add(gui_ingame_pause);
	}

	@Override
	public void updateButtons() 
	{
		this.button_ingame_resume.update();
		this.button_ingame_saveWorld.update();
		this.button_ingame_options.update();
		this.button_ingame_backToMenu.update();
		this.button_ingame_closeGame.update();
	}

}
