package com.kenny.craftix.client.gui.button;

import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector2f;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.font.GuiText;
import com.kenny.craftix.client.gui.Gui;
import com.kenny.craftix.client.gui.GuiScaled;
import com.kenny.craftix.client.gui.GuiYesNo;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.resources.StillWorking;
import com.kenny.craftix.client.scenes.MainMenuScene;

public class GuiButton //implements IButton
{
	/**Called GuiTexture class.*/
	private Gui guis;
	/**This is scale of the button*/
	private boolean isHidden = false;
	private boolean isVisible = false;
	private boolean isHovering = false;
	public Vector2f originalScale;
	public Loader loader;
	public GuiScaled guiScaled;
	/**Its original X scale of button.*/
	public static float x = 0.00f;
	/**Its original Y scale of button.*/
	public static float y = 0.00f;
	public MainMenuScene mms = new MainMenuScene();
	
	public GuiButton(String textureName, Vector2f position, Vector2f scale)
	{
		this.loader = new Loader();
		this.guis = new Gui(this.loader.loadTexture(textureName), position, scale);
		this.originalScale = scale;	
	}
	
	/**
	 * With use Gui scale system.
	 */
	public GuiButton(String textureName, Vector2f position)
	{
		this.loader = new Loader();
		this.guiScaled = new GuiScaled();
		this.originalScale = new Vector2f(x, y);
		this.guis = new Gui(this.loader.loadTexture(textureName), position,
				this.originalScale);
	}
	
	/**
	 * With use Gui scale system and can use custom X or Y for change something button.
	 */
	public GuiButton(String textureName, Vector2f position, 
			float customX, float customY)
	{
		this.loader = new Loader();
		this.guiScaled = new GuiScaled();
		this.originalScale = new Vector2f(x + customX, y + customY);
		this.guis = new Gui(this.loader.loadTexture(textureName), position,
				this.originalScale);
	}
	
	/**
	 * With use Gui scale system and can use custom X or Y for change something button.
	 * For button Yes.
	 */
	public GuiButton(String textureName, Vector2f position, 
			float customX, float customY, boolean isYes)
	{
		this.loader = new Loader();
		this.guiScaled = new GuiScaled();
		GuiYesNo.isYesOptionFS = isYes;
		this.originalScale = new Vector2f(x + customX, y + customY);
		this.guis = new Gui(this.loader.loadTexture(textureName), position,
				this.originalScale);
	}
	
	public GuiButton(String textureName, GuiText text, Vector2f position, Vector2f scale)
	{
		this.loader = new Loader();
		this.guis = new Gui(this.loader.loadTexture(textureName), position, scale);
		this.originalScale = scale;
		
	}
	/**
	 *This is a simple update method for buttons.
	 */
	public void update()
	{
		if (!isHidden) 
		{
	        Vector2f location = guis.getPosition();
	        Vector2f scale = guis.getScale();
	        Vector2f mouseCoordinates = Craftix.getNormalizedMouseCoords();
	            
	        if (location.y + scale.y > -mouseCoordinates.y && location.y - scale.y < -mouseCoordinates.y 
	            && location.x + scale.x > mouseCoordinates.x && location.x - scale.x < mouseCoordinates.x)
	        {
	            whileHovering(this);
	            if (!this.isHovering) 
	            {
	                this.isHovering = true;
	                onStartHover(this);
	            }
	            else
	            {
	            	 if (Mouse.isButtonDown(0) && this.isVisible)
		     	           onClick(this);
		     	           isVisible(this);
	            }
	        } 
	        else 
	        {
	            if (this.isHovering) 
	            {
	                this.isHovering = false;
	                onStopHover(this);
	            }
	        }
	    }
	}
	
	private void isVisible(GuiButton guiButton) {
		// TODO Auto-generated method stub
		
	}

	/**
	 *This is a simple update method for multi-combinate buttons. Like a Yes-No or 1-2-3 and etc..
	 */
	public void updateMulti()
	{
		if (!isHidden) 
		{
	        Vector2f location = guis.getPosition();
	        Vector2f scale = guis.getScale();
	        Vector2f mouseCoordinates = Craftix.getNormalizedMouseCoords();
	            
	        if (location.y + scale.y > -mouseCoordinates.y && location.y - scale.y < -mouseCoordinates.y 
	            && location.x + scale.x > mouseCoordinates.x && location.x - scale.x < mouseCoordinates.x)
	        {
	            whileHovering(this);
	            if (!this.isHovering) 
	            {
	                this.isHovering = true;
	                onStartHover(this);
	            }
	            boolean isCombinateMulti;
	            isCombinateMulti = true;
	            if(isCombinateMulti)
	            {
	            	while(Mouse.next())
	     	           if (Mouse.isButtonDown(0) && this.isVisible)
	     	           onClick(this);
	     	           isVisible(this);
	            }
	            else
	            {
	            	 if (Mouse.isButtonDown(0) && this.isVisible)
		     	           onClick(this);
		     	           isVisible(this);
	            }
	        } 
	        else 
	        {
	            if (this.isHovering) 
	            {
	                this.isHovering = false;
	                onStopHover(this);
	            }
	        }
	    }
	}
	
	public void isVisible(GuiAbstractButton button)
	{
		this.isVisible = true;
	}
	
	public void stopUpdate()
	{
		boolean update = false;
			if(update == true)
				this.update();
	}
	
	public void update2(GuiAbstractButton button)
	{
		if (!isHidden) 
		{
	        Vector2f location = guis.getPosition();
	        Vector2f scale = guis.getScale();
	        Vector2f mouseCoordinates = Craftix.getNormalizedMouseCoords();
	            
	        if (location.y + scale.y > -mouseCoordinates.y && location.y - scale.y < -mouseCoordinates.y 
	            && location.x + scale.x > mouseCoordinates.x && location.x - scale.x < mouseCoordinates.x)
	        {
	            whileHovering(this);
	            if (!this.isHovering) 
	            {
	                this.isHovering = true;
	                onStartHover(this);
	            }
	            while (Mouse.next())
	                if (Mouse.isButtonDown(0))
	                this.onClickMouse(button);
	        } 
	        else 
	        {
	            if (this.isHovering) 
	            {
	                this.isHovering = false;
	                onStopHover(this);
	            }
	        }
	    }
	}
	
	public void onClickMouse(GuiAbstractButton button)
	{
		//Craftix craftix = new Craftix();
		//craftix.play();
	}

	
	private void startRender(List<Gui> guiTextureList)
	{
	    guiTextureList.add(guis);
	}
 
	private void stopRender(List<Gui> guiTextureList)
	{
	    guiTextureList.remove(guis);
	}
	
	
	public void hide(List<Gui> guiTextures) 
	{
		stopRender(guiTextures);
		isHidden = true;
	}
	 
	public void show(List<Gui> guiTextures) 
	{
	    startRender(guiTextures);
	    isHidden = false;
	}
	
	
	public void resetScale()
	{
		this.guis.setScale(originalScale);
	}
	
	/**
	 * In the future am be working on sound system in the game engine, and add click-button
	 * sound.
	 */
	@StillWorking
	public void playSound(float sound)
	{
		
	}
	
	public void playHoverAnimation(float scaleFactor)
	{
		this.guis.setScale(new Vector2f(originalScale.x + scaleFactor, originalScale.y + scaleFactor));
	}
	public boolean isHidden() 
	{
		return isHidden;
	}

	
	public GuiButton onClick(GuiButton guiButton) 
	{	
		return guiButton;
	}

	
	protected void onStartHover(GuiButton guiButton) 
	{
	}

	
	protected void onStopHover(GuiButton guiButton)
	{
	}

	
	protected void whileHovering(GuiButton guiButton) 
	{
	}

	
	public void isVisible(boolean isVisible) 
	{
	}
	
	
}
