package com.kenny.craftix.client.gui;

public class GuiRenderManager 
{
	public static boolean renderMainMenu = true;
	public static boolean renderOptionsMenu = false;
	public static boolean renderOptionsInGame = false;
	public static boolean renderCreditsMenu = false;
	public static boolean renderUpdatesMenu = false;
	public static boolean renderSingleplayerMenu = false;
	public static boolean renderInGameMenu = false;
	public static boolean renderLanguageMenu = false;
	public static boolean renderGraphicMenu = false;
	public static boolean renderAudioMenu = false;
	public static boolean renderAudioMenuInGame = false;
	public static boolean renderGame = false;
	public static boolean renderLoadingSplash = false;
	public static boolean renderGameOver = false;
}
