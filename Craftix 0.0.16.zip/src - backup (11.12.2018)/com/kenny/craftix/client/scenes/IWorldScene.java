package com.kenny.craftix.client.scenes;

public interface IWorldScene 
{
	/**
	 * Render the option gui when user in game-world scene.
	 */
	public void renderOptions();
	
}
