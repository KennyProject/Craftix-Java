package com.kenny.craftix.client.scenes;

public class LowPolyWorldScene
{

}
