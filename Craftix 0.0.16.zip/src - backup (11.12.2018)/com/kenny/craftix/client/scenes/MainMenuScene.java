package com.kenny.craftix.client.scenes;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.audio.sound.SoundLoader;
import com.kenny.craftix.client.entity.EntityCamaraInMenu;
import com.kenny.craftix.client.font.render.FontRenderer;
import com.kenny.craftix.client.font.render.TextMaster;
import com.kenny.craftix.client.gui.GuiAudio;
import com.kenny.craftix.client.gui.GuiCreditsMenu;
import com.kenny.craftix.client.gui.GuiGame;
import com.kenny.craftix.client.gui.GuiGraphics;
import com.kenny.craftix.client.gui.GuiLanguage;
import com.kenny.craftix.client.gui.GuiLatestUpdates;
import com.kenny.craftix.client.gui.GuiMainMenu;
import com.kenny.craftix.client.gui.GuiOptionsMenu;
import com.kenny.craftix.client.gui.GuiRenderManager;
import com.kenny.craftix.client.gui.GuiRenderer;
import com.kenny.craftix.client.gui.GuiScaled;
import com.kenny.craftix.client.gui.GuiSingleplayer;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.renderer.MainMenuRenderer;
import com.kenny.craftix.client.renderer.WorldRenderer;
import com.kenny.craftix.client.renderer.GlHelper.Framebuffer;
import com.kenny.craftix.client.renderer.postEffects.PanoramaBlur;
import com.kenny.craftix.client.settings.InGameSettings;
import com.kenny.craftix.client.shaders.EntityShader;
import com.kenny.craftix.client.shaders.FrameBuffer;
import com.kenny.craftix.init.EntityInit;
import com.kenny.craftix.init.TextInit;
import com.kenny.craftix.utils.MouseHelper;
import com.kenny.craftix.world.skybox.SkyboxPanoramaShader;

public class MainMenuScene implements IScene, IReloadble
{
	/**Check if user now in main menu.*/
	public static boolean isInMainMenu;
	public boolean useRu = false;
	public boolean useEn = false;
	
	public Craftix cx;
	/**The core of the entire engine.*/
	public Loader loader;
	/**Old initialization of the guis.*/
	private GuiGame guiInit;
	/**Render the guis into the game engine.*/
	public GuiRenderer guiRenderer;
	/**Initialize all texts to the game engine.*/
	public TextInit textInit;
	public MouseHelper mouseHelper;
	@SuppressWarnings("unused")
	private GuiScaled guiScaled = new GuiScaled();
	/**Load the guis of the main page menu screen.*/
	public GuiMainMenu guiMainMenu = new GuiMainMenu();
	/**Load the gui screen with options.*/
	public GuiOptionsMenu guiOptionsMenu = new GuiOptionsMenu();
	/**Load the gui screen with credits texts.*/
	public GuiCreditsMenu guiCreditsMenu = new GuiCreditsMenu();
	/**Load the gui screen with singleplayer texts.*/
	public GuiSingleplayer guiSingleplayerMenu = new GuiSingleplayer();
	/**Load the gui screen with language texts.*/
	public GuiLanguage guiLanguageMenu = new GuiLanguage();
	/**Load the gui screen with graphics texts.*/
	public GuiGraphics guiGraphics = new GuiGraphics();
	/**Load the gui screen with audio texts.*/
	public GuiAudio guiAudio = new GuiAudio();
	public GuiLatestUpdates guiLatestUpdates = new GuiLatestUpdates();
	public boolean loadText;
	public FontRenderer textRenderer;
	public EntityShader shader;
	public WorldRenderer renderer;
	public MainMenuRenderer panoramaRenderer;
	public EntityInit entityInit;
	public SkyboxPanoramaShader skyboxPanoramaShader;
	/**Audio Master's components.*/
	public float volume;
	public EntityCamaraInMenu camera;
	/**Multisamle the framebuffer for post-proccessing effects.*/
	public static FrameBuffer multisampleFrameBuffer;
	/**Outputs the converted frame buffer.*/
	public static FrameBuffer outputFrameBuffer;
	public static FrameBuffer outputFrameBuffer2;
	
	
	@Override
	public void loadScene() 
	{
		multisampleFrameBuffer = new FrameBuffer(Display.getWidth(), Display.getHeight());
		outputFrameBuffer = new FrameBuffer(Display.getWidth(), Display.getHeight(), FrameBuffer.DEPTH_TEXTURE);
		outputFrameBuffer2 = new FrameBuffer(Display.getWidth(), Display.getHeight(), FrameBuffer.DEPTH_TEXTURE);
		GuiRenderManager.renderGame = false;
		this.loadText = true;
		SoundLoader.loadGameSounds();
		this.mouseHelper = new MouseHelper();
		this.loader = new Loader();
		this.panoramaRenderer = new MainMenuRenderer(this.loader);
		this.renderer = new WorldRenderer(this.loader);
		this.shader = new EntityShader();
		this.entityInit = new EntityInit();
		this.skyboxPanoramaShader = new SkyboxPanoramaShader();
		this.guiInit = new GuiGame();
		TextMaster.textMenu = true;
		this.textInit = new TextInit();//
		this.textRenderer = new FontRenderer();//
		this.camera = new EntityCamaraInMenu();
		PanoramaBlur.init(loader);
		this.guiRenderer = new GuiRenderer(this.loader);
		this.entityInit.loadMainCraftixBox();
		this.textInit.loadEngineText();//
		this.guiMainMenu.loadMainMenuScreen();
		this.guiOptionsMenu.loadOptionsMenuScreen();
		this.guiLatestUpdates.loadLatestUpdatesScreen();
		this.guiGraphics.loadGraphicsScreen();
		this.guiAudio.loadAudioScreen();
		this.guiLanguageMenu.loadLanguageScreen();
		this.guiCreditsMenu.loadCreditsMenuScreen();
		this.guiSingleplayerMenu.loadSingleplayerScreen();
		GuiRenderManager.renderGameOver = false;
		this.playSound();
	}
	
	@Override
	public void reloadScene() 
	{
		
	}

	@Override
	public void renderScene() 
	{
		this.panoramaRenderer.renderMainMenu(camera);
		this.skyboxPanoramaShader.setRotationSpeedSkybox(2f);
		multisampleFrameBuffer.bindFrameBuffer();
		multisampleFrameBuffer.unbindFrameBuffer();
		multisampleFrameBuffer.resolveToFrameBuffer(Framebuffer.COLOR_ATTACHMENT0, outputFrameBuffer);
		multisampleFrameBuffer.resolveToFrameBuffer(Framebuffer.COLOR_ATTACHMENT1, outputFrameBuffer2);
		
		PanoramaBlur.doPanoramaBlur(outputFrameBuffer.getColourTexture());
		this.guiRenderer.render(this.guiMainMenu.guisMenuMainBackground);
		this.guiRenderer.render(this.guiInit.guisGameButtons);
		
		if(Keyboard.isKeyDown(Keyboard.KEY_5))
		{SoundLoader.sourceMenu1.volume00();}
		if(Keyboard.isKeyDown(Keyboard.KEY_6))
		{SoundLoader.sourceMenu1.volume02();}
		if(Keyboard.isKeyDown(Keyboard.KEY_7))
		{SoundLoader.sourceMenu1.volume04();}
		if(Keyboard.isKeyDown(Keyboard.KEY_8))
		{SoundLoader.sourceMenu1.volume06();}
		if(Keyboard.isKeyDown(Keyboard.KEY_9))
		{SoundLoader.sourceMenu1.volume08();}
		if(Keyboard.isKeyDown(Keyboard.KEY_0))
		{SoundLoader.sourceMenu1.volume10();}
		
		if(Keyboard.isKeyDown(Keyboard.KEY_NUMPAD4))
		{this.skyboxPanoramaShader.setRotationSpeedSkybox(-2);}
		if(Keyboard.isKeyDown(Keyboard.KEY_NUMPAD5))
		{this.skyboxPanoramaShader.setRotationSpeedSkybox(0);}
		if(Keyboard.isKeyDown(Keyboard.KEY_NUMPAD6))
		{this.skyboxPanoramaShader.setRotationSpeedSkybox(2);}
		
		if(Keyboard.isKeyDown(Keyboard.KEY_MINUS))
		{
			this.decreasePlayingSound();
		}
		
		if(GuiRenderManager.renderMainMenu)
		{
			this.guiMainMenu.updateButtons();
			this.guiRenderer.render(this.guiMainMenu.guisMenuMainButtons);
			this.textRenderer.renderEngineText(this.textInit.text1);
		}
		if(GuiRenderManager.renderOptionsMenu)
		{
			this.guiOptionsMenu.updateButtons();
			this.guiRenderer.render(this.guiOptionsMenu.guisMenuOptionsButtons);
		}
		if(GuiRenderManager.renderUpdatesMenu)
		{
			this.guiLatestUpdates.updateButtons();
			this.guiRenderer.render(this.guiLatestUpdates.guislUpdatesButtons);
			this.guiRenderer.render(this.guiLatestUpdates.guislUpdatesBackground);
		}
		if(GuiRenderManager.renderGraphicMenu)
		{
			this.guiGraphics.updateButtons();
			this.guiRenderer.render(this.guiGraphics.guisGraphicsBackground);
			this.guiRenderer.render(this.guiGraphics.guisGraphicsButtons);
		}
		if(GuiRenderManager.renderAudioMenu)
		{
			this.guiAudio.updateButtons();
			this.guiRenderer.render(this.guiAudio.guisAudioBackground);
			this.guiRenderer.render(this.guiAudio.guisAudioButtons);
		}
		if(GuiRenderManager.renderLanguageMenu)
		{
			this.guiLanguageMenu.updateButtons();
			this.guiRenderer.render(this.guiLanguageMenu.guisLanguageBackground);
			this.guiRenderer.render(this.guiLanguageMenu.guisLanguageButtons);
		}
		if(GuiRenderManager.renderCreditsMenu)
		{
			this.guiCreditsMenu.updateButtons();
			this.guiRenderer.render(this.guiCreditsMenu.guisMenuCreditsButtons);
		}
		
		if(GuiRenderManager.renderSingleplayerMenu)
		{
			this.guiSingleplayerMenu.updateButtons();
			this.guiRenderer.render(this.guiSingleplayerMenu.guisSinglepBackground);
			this.guiRenderer.render(this.guiSingleplayerMenu.guisSinglepButtons);
		}
		
		TextMaster.renderEngineText();
	}

	public void selectRussianLang()
	{
		this.useEn = false;
		this.useRu = true;
		if(useRu)
		{
			TextMaster.textMenu = false;
			TextInit.removeLanguagePage();
			TextInit textInit = new TextInit();
			textInit.loadDefaultFonts(textInit.loader);
			textInit.ruRu.loadRuLocalization();
			textInit.initLanguagePage(textInit.loader);
			TextMaster.textMenu = true;
			Craftix.LOGGER.info("Language set on: Russian!" );
		}
		else 
		{
			;
		}
	}
	
	public void selectEnglishLang()
	{
		this.useRu = false;
		this.useEn = true;
		if(useEn)
		{
			TextMaster.textMenu = false;
			TextInit.removeLanguagePage();
			TextInit textInit = new TextInit();
			textInit.loadDefaultFonts(textInit.loader);
			textInit.usEn.loadUsEnLocalization();
			textInit.initLanguagePage(textInit.loader);
			TextMaster.textMenu = true;
			Craftix.LOGGER.info("Language set on: English!" );
		}
		else
		{
			;
		}
	}

	
	@Override
	public void otherSetup() 
	{
	}
	
	public void playSound()
	{
		this.volume = 1f;
		if(InGameSettings.useAudioIn)
		{
			SoundLoader.sourceMenu1.setVolume(volume);
			SoundLoader.sourceMenu1.setPitch(1f);
			SoundLoader.soundPlay(SoundLoader.sourceMenu1, SoundLoader.bufferMenu1);
			
		}
	}
	
	public void increasePlayingSound()
	{
		this.volume = volume + 0.1f;
	}
	
	public void decreasePlayingSound()
	{
		this.volume--;
	}

	@Override
	public void cleanUpScene() 
	{
		this.textRenderer.cleanUp();
		TextMaster.cleanUp();
		this.guiRenderer.cleanUp();
		this.shader.cleanUp();
		SoundLoader.cleanUpSounds();
	}

}
