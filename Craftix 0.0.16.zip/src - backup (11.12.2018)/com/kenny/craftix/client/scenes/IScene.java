package com.kenny.craftix.client.scenes;

/**
 * The main components necessary to create a scene.
 * 
 * @author Kenny
 */
public interface IScene 
{
	/**This method will add objects, entities, and various engine components.*/
	public void loadScene();
	/**This is the rendering of the whole scene. Display GUI/UI, light. Everything 
	 * that will be added to this method will be rendered in the scene.*/
	public void renderScene();
	/**Setup other scene components. Like a light, test buttons, hitboxes, 
	 * collisions and etc...*/
	public void otherSetup();
	/**Remove unnecessary buffer shaders to re-create this scene. 
	 * Or to exit the game*/
	public void cleanUpScene();
}
