package com.kenny.craftix.client.entity.player;

public class PlayerInput 
{
	
}
