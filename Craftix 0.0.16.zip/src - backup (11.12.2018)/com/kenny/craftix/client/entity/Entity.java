package com.kenny.craftix.client.entity;

import org.lwjgl.util.vector.Vector3f;

import com.kenny.craftix.client.renderer.models.ModelBase;

public class Entity 
{
	/**We get the textured model for entity*/
	private ModelBase model;
	/**This is postion of entity*/
	public Vector3f position;
	public static Vector3f positionS;
	/**Rotation entity on X axis*/
	private float rotX;
	/**Rotation entity on Y axis*/
	private float rotY;
	/**Rotation entity on Z axis*/
	private float rotZ;
	/**Scale model entity*/
	private float scale;
	
	private int textureIndex = 0;
	
	public Entity(ModelBase model, Vector3f position, float rotX, float rotY, 
			float rotZ, float scale) 
	{
		super();
		this.model = model;
		this.position = position;
		positionS = position;
		this.rotX = rotX;
		this.rotY = rotY;
		this.rotZ = rotZ;
		this.scale = scale;
	}
	
	public Entity(ModelBase model, int index, Vector3f position, float rotX, float rotY, 
			float rotZ, float scale) 
	{
		super();
		this.model = model;
		this.textureIndex = index;
		this.position = position;
		positionS = position;
		this.rotX = rotX;
		this.rotY = rotY;
		this.rotZ = rotZ;
		this.scale = scale;
	}
	
	public Entity()
	{
	}
	
	public float getTextureXOffset()
	{
		int column = textureIndex % model.getTexture().getNumberOfRows();
		return (float) column / (float) model.getTexture().getNumberOfRows();
	}
	
	public float getTextureYOffset()
	{
		int row = textureIndex % model.getTexture().getNumberOfRows();
		return (float) row / (float) model.getTexture().getNumberOfRows();
	}
	
	public void increasePosition(float dX, float dY, float dZ)
	{
		this.position.x += dX;
		this.position.y += dY;
		this.position.z += dZ;
	}
	
	public void increaseRotation(float dX, float dY, float dZ)
	{
		this.rotX += dX;
		this.rotY += dY;
		this.rotZ += dZ;
	}

	public ModelBase getModel() 
	{
		return model;
	}

	public void setModel(ModelBase model) 
	{
		this.model = model;
	}

	public Vector3f getPosition() 
	{
		return position;
	}

	public void setPosition(Vector3f position) 
	{
		this.position = position;
	}
	
	public static void setStaticPosition(Vector3f position) 
	{
		positionS = position;
	}

	public float getRotX() 
	{
		return rotX;
	}

	public void setRotX(float rotX) 
	{
		this.rotX = rotX;
	}

	public float getRotY() 
	{
		return rotY;
	}

	public void setRotY(float rotY) 
	{
		this.rotY = rotY;
	}

	public float getRotZ() 
	{
		return rotZ;
	}

	public void setRotZ(float rotZ) 
	{
		this.rotZ = rotZ;
	}

	public float getScale() 
	{
		return scale;
	}

	public void setScale(float scale) 
	{
		this.scale = scale;
		
	}
	
	
	
}
