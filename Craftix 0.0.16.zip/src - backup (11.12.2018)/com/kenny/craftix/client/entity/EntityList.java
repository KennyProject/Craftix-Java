package com.kenny.craftix.client.entity;


public class EntityList 
{
	public static void addEntity()
	{
		//TexturedModel entityTree;
		//TexturedModel entityGrass;
		//TexturedModel entityFern;
	}
}
