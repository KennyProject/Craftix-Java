package com.kenny.craftix.client.loader;

public enum GameState 
{
	MENU,
	GAME;
	
	public void menu()
	{
		if(MENU != null)
		{
			
		}
	}
}
