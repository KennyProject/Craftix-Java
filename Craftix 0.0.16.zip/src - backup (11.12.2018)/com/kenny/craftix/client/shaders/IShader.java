package com.kenny.craftix.client.shaders;

public interface IShader 
{
	
}
