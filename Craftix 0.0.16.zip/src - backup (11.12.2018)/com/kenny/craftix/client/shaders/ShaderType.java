package com.kenny.craftix.client.shaders;

public enum ShaderType 
{
	VERTEX_TYPE,
	FRAGMENT_TYPE;
	
	public static final String VERTEX = ".vert";
	public static final String GEOMETRY = ".geo";
	public static final String FRAGMENT = ".frag";
	
	public void type()
	{
		
		
	
	}
}
