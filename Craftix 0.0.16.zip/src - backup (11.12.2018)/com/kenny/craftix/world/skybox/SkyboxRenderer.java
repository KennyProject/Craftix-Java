package com.kenny.craftix.world.skybox;

import org.lwjgl.util.vector.Matrix4f;

import com.kenny.craftix.client.entity.EntityCamera;
import com.kenny.craftix.client.loader.Loader;
import com.kenny.craftix.client.renderer.GlHelper;
import com.kenny.craftix.client.renderer.GlHelper.Texture;
import com.kenny.craftix.client.renderer.WorldRenderer;
import com.kenny.craftix.client.renderer.models.Model;
import com.kenny.craftix.client.renderer.textures.TextureManager;
import com.kenny.craftix.utils.Timer;

public class SkyboxRenderer 
{
	public static final String SKYBOX_FOLDER = new String("skybox/");
	/**These values are needed to adjust the rendering of the skybox*/
	public static final float LOWER_LIMIT = -10.0f;
	public static final float UPPER_LIMIT = 30.0f;
	/**This is a Raw Model for skybox cube*/
	private Model cube;
	/**This is a textures for day time*/
	private int skyboxDayTextures;
	/**This is a textures for night time*/
	private int skyboxNightTextures;
	private Timer timer = new Timer();
	private SkyboxShader shader;
	public static float time = 0;
	/**This is a size of skybox*/
	private static final float SIZE = 500f;
	/**Its a simple verties of skybox*/
	private static final float[] VERTICES = {        
		    -SIZE,  SIZE, -SIZE,
		    -SIZE, -SIZE, -SIZE,
		    SIZE, -SIZE, -SIZE,
		     SIZE, -SIZE, -SIZE,
		     SIZE,  SIZE, -SIZE,
		    -SIZE,  SIZE, -SIZE,

		    -SIZE, -SIZE,  SIZE,
		    -SIZE, -SIZE, -SIZE,
		    -SIZE,  SIZE, -SIZE,
		    -SIZE,  SIZE, -SIZE,
		    -SIZE,  SIZE,  SIZE,
		    -SIZE, -SIZE,  SIZE,

		     SIZE, -SIZE, -SIZE,
		     SIZE, -SIZE,  SIZE,
		     SIZE,  SIZE,  SIZE,
		     SIZE,  SIZE,  SIZE,
		     SIZE,  SIZE, -SIZE,
		     SIZE, -SIZE, -SIZE,

		    -SIZE, -SIZE,  SIZE,
		    -SIZE,  SIZE,  SIZE,
		     SIZE,  SIZE,  SIZE,
		     SIZE,  SIZE,  SIZE,
		     SIZE, -SIZE,  SIZE,
		    -SIZE, -SIZE,  SIZE,

		    -SIZE,  SIZE, -SIZE,
		     SIZE,  SIZE, -SIZE,
		     SIZE,  SIZE,  SIZE,
		     SIZE,  SIZE,  SIZE,
		    -SIZE,  SIZE,  SIZE,
		    -SIZE,  SIZE, -SIZE,

		    -SIZE, -SIZE, -SIZE,
		    -SIZE, -SIZE,  SIZE,
		     SIZE, -SIZE, -SIZE,
		     SIZE, -SIZE, -SIZE,
		    -SIZE, -SIZE,  SIZE,
		     SIZE, -SIZE,  SIZE
		};
	
	private static String[] SKYBOX_DAY = 
	{
		SKYBOX_FOLDER + "s_day_right",
		SKYBOX_FOLDER + "s_day_left",
		SKYBOX_FOLDER + "s_day_up",
		SKYBOX_FOLDER + "s_day_down",
		SKYBOX_FOLDER + "s_day_back",
		SKYBOX_FOLDER + "s_day_front"
	};
	
	private static String[] SKYBOX_NIGHT = 
	{
		SKYBOX_FOLDER + "s_night_right",
		SKYBOX_FOLDER + "s_night_left",
		SKYBOX_FOLDER + "s_night_top",
		SKYBOX_FOLDER + "s_night_bottom",
		SKYBOX_FOLDER + "s_night_back",
		SKYBOX_FOLDER + "s_night_front"
	};
		
	/**
	 * That means when player reload the scene, the cycle time sets back to 0.
	 * 
	 * @param cycleTime - its a engine day time.
	 */
	public static void setDayCicleTime(float cycleTime)
	{
		time = cycleTime;
	}
	
	public static float getDayCycleTime()
	{
		return time;
	}
	
	public SkyboxRenderer(Loader loader, Matrix4f projectionMatrix)
	{
		this.cube = loader.loadToVAO(VERTICES, 3);
		this.skyboxDayTextures = loader.loadCubeMapNew(SKYBOX_DAY);
		this.skyboxNightTextures = loader.loadCubeMapNew(SKYBOX_NIGHT);
		this.shader = new SkyboxShader();
		this.shader.start();
		this.shader.connectTextureunits();
		this.shader.loadProjectionMatrix(projectionMatrix);
		this.shader.stop();
	}
	
	public void render(EntityCamera camera, float r, float g, float b)
	{
		this.shader.start();
		this.shader.loadViewMatrix(camera);
		this.shader.loadFogColour(r, g, b);
		this.shader.loadLowerLimit(LOWER_LIMIT);
		this.shader.loadUpperLimit(UPPER_LIMIT);
		GlHelper.glBindVertexArray(cube.getVaoID());
		GlHelper.glEnableVertexAttribArray(0);
		this.bindTextures();
		GlHelper.glDrawArrays(Texture.TRIANGLES, 0, cube.getVertexCount());
		GlHelper.glDisableVertexAttribArray(0);
		GlHelper.glBindVertexArray(0);
		this.shader.stop();
	}
	
	private void bindTextures()
	{
		time += this.timer.getFrameTimeSeconds() * 5;
		time %= 24000;
		int texture0;
		int texture1;
		float blendFactor;		
		if(time >= 0 && time < 5000){
			texture0 = skyboxDayTextures;
			texture1 = skyboxDayTextures;
			blendFactor = (time - 0)/(5000 - 0);
		}else if(time >= 5000 && time < 8000)
		{
			texture0 = skyboxDayTextures;
			texture1 = skyboxNightTextures;
			blendFactor = (time - 5000)/(8000 - 5000);
			WorldRenderer.FOG_RED = 0.01f;
			WorldRenderer.FOG_GREEN = 0.01f;
			WorldRenderer.FOG_BLUE = 0.01f;
		}else if(time >= 8000 && time < 21000)
		{
			texture0 = skyboxNightTextures;
			texture1 = skyboxNightTextures;
			WorldRenderer.FOG_RED = 0.01f;
			WorldRenderer.FOG_GREEN = 0.01f;
			WorldRenderer.FOG_BLUE = 0.01f;
			blendFactor = (time - 8000)/(21000 - 8000);
		}else{
			texture0 = skyboxNightTextures;
			texture1 = skyboxDayTextures;
			WorldRenderer.FOG_RED = 0.5444f;
			WorldRenderer.FOG_GREEN = 0.62f;
			WorldRenderer.FOG_BLUE = 0.69f;
			blendFactor = (time - 21000)/(24000 - 21000);
		}

		TextureManager.activeTexture0();
		TextureManager.bindTextureCubeMap(texture0);
		TextureManager.activeTexture1();
		TextureManager.bindTextureCubeMap(texture1);
		this.shader.loadBlendFactor(blendFactor);
		
	}
}
