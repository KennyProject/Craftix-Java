package com.kenny.craftix.main;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;

import com.kenny.craftix.client.Craftix;
import com.kenny.craftix.client.resources.StillWorking;
import com.kenny.launcher.CraftixLauncher;

public class Main 
{
	public static final Logger LOGGER = LogManager.getLogger();
	
	public static void main(String [] args) throws LWJGLException, IOException
	{
		Craftix cx = new Craftix();
		CraftixLauncher cxLauncher = new CraftixLauncher();
		cx.isRunningWithLauncher = false;
		if(!cx.isRunningWithLauncher)
		{
			cx.run();
		}
		else
		{
			cxLauncher.run();
		}
	}
	
	/**
	 * Its not working now. When the boot system to the option file appears then 
	 * it will possibly work.
	 */
	@StillWorking
	public void GameOption()
	{
		
	}
}
