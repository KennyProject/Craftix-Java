package com.kenny.craftix.main;

import java.io.File;

public class GameConfiguration 
{
	public final GameConfiguration.FolderInformation folderInfo;
	
	public GameConfiguration(GameConfiguration.FolderInformation folderInfoIn)
	{
		this.folderInfo = folderInfoIn;
	}
	
	public static class FolderInformation
	{
		public final File cxDataDir;
		
		public FolderInformation(File cxDataDirIn)
		{
			this.cxDataDir = cxDataDirIn;
		}

	}
}
