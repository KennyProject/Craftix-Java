package com.kenny.craftix.utils.data;

public interface IFixType 
{
}
