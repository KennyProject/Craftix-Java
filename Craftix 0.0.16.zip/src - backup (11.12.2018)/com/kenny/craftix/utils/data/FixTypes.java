package com.kenny.craftix.utils.data;

public enum FixTypes implements IFixType
{
	SCENE,
	PLAYER,
	OPTIONS;
}
