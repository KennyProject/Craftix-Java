package com.kenny.craftix.utils;

public @interface KennyCopyright 
{
}

